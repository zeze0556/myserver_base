// SPDX-FileCopyrightText: 2011 Mathieu Desnoyers <mathieu.desnoyers@efficios.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#warning "urcu/urcu-futex.h is deprecated. Please include urcu/futex.h instead."
#include <urcu/futex.h>
