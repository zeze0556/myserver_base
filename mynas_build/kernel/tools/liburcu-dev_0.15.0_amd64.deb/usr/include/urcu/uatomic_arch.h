// SPDX-FileCopyrightText: 2011 Mathieu Desnoyers <mathieu.desnoyers@efficios.com>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#warning "urcu/uatomic_arch.h is deprecated. Please include urcu/uatomic.h instead."
#include <urcu/uatomic.h>
